//
//  OrderResponse.swift
//  SchoolStore
//
//  Created by a1 on 21.10.2021.
//

import Foundation

struct GetListOfOrdersResponse: Decodable {
    let orders: [Order]
}
