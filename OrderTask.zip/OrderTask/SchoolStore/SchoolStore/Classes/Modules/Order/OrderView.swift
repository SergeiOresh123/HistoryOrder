//
//  OrderView.swift
//  SchoolStore
//
//  Created by Heads on 25.10.2021.
//

import AutoLayoutSugar
import Kingfisher
import UIKit

final class OrderView: UIView {
    // MARK: Lifecycle

    override init(frame: CGRect) {
        super.init(frame: frame)
        translatesAutoresizingMaskIntoConstraints = false
        setup()
        createDatePick()
        buyNowButton.addTarget(self, action: #selector(buyBtn), for: .touchUpInside)
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        createDatePick()
        setup()
        buyNowButton.addTarget(self, action: #selector(buyBtn), for: .touchUpInside)
    }

    // MARK: Internal

    func fillWith(product: Product?) {
        guard let product = product else {
            return
        }

        if let previewUrl = URL(string: product.preview) {
            let contentImageResource = ImageResource(downloadURL: previewUrl, cacheKey: product.preview)
            mainImageView.kf.setImage(
                with: contentImageResource,
                placeholder: Asset.itemPlaceholder.image,
                options: [
                    .transition(.fade(0.2)),
                    .forceTransition,
                    .cacheOriginalImage,
                    .keepCurrentImageWhileLoading,
                ]
            )
        } else {
            mainImageView.image = Asset.itemPlaceholder.image
        }
        
    }

    // MARK: Private

    private let textPrimaryColor: UIColor = Asset.textPrimary.color
    private let textSecondaryColor: UIColor = Asset.textSecondary.color
    
    private lazy var quantity: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var stepCounter: UIStepper = {
        let sc = UIStepper()
        sc.translatesAutoresizingMaskIntoConstraints = false
        sc.minimumValue = 1
        sc.maximumValue = 10
        sc.addTarget(self, action: #selector(update(_ :)), for: .valueChanged)
        sc.value = 1
    
        return sc
    }()
    
    private lazy var datePick: UIDatePicker = {
       let dp = UIDatePicker()
        dp.translatesAutoresizingMaskIntoConstraints = false
        return dp
    }()

    private lazy var mainImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private lazy var stepperView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private lazy var departmentLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private lazy var sizeLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var houseField: InputField = {
        let hf = InputField()
        hf.translatesAutoresizingMaskIntoConstraints = false
        return hf
    }()
    
    private lazy var roomField: InputField = {
        let rf = InputField()
        rf.translatesAutoresizingMaskIntoConstraints = false
        return rf
    }()
    
    private lazy var dateField: InputField = {
        let df = InputField()
        df.translatesAutoresizingMaskIntoConstraints = false
        return df
    }()

    private lazy var separatorView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var buyNowButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.tintColor = .white
        button.setTitle("Купить", for: .normal)
        button.backgroundColor = .blue
        button.layer.cornerRadius = 8
        return button
    }()

    @objc private func update(_ sender: UIStepper){
        
        quantity.text = "\(Int(stepCounter.value))"
    }
    
    @objc private func buyBtn() {

        print("Куплено единиц товара: \(Int(stepCounter.value))")
    }
    
    @objc func doneBtnClick() {
            let dateFormatter = DateFormatter()
            
            dateFormatter.dateStyle = .medium
            dateFormatter.timeStyle = .none
            
            self.dateField.text = dateFormatter.string(from: datePick.date)
            self.endEditing(true)
        }
    
    private func toolBarCreate() -> UIToolbar {
            let toolbar = UIToolbar()
            toolbar.sizeToFit()
            
            let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(doneBtnClick))
            
            toolbar.setItems([doneBtn], animated: true)
            
            return toolbar
        }
    
    private func createDatePick() {
            datePick.preferredDatePickerStyle = .wheels
            datePick.datePickerMode = .date
            
            dateField.textField.inputView = datePick
            dateField.textField.inputAccessoryView = toolBarCreate()
        }
    
    @objc
    private func previewDidTap(_ sender: UIButton) {
        guard let imageView = sender.subviews.first(where: { $0 is UIImageView }) as? UIImageView,
              let image = imageView.image
        else {
            return
        }
        mainImageView.image = image
    }

    private func setup() {
        addSubview(stepperView)
        stepperView.addSubview(quantity)
        stepperView.addSubview(stepCounter)
        addSubview(mainImageView)
        addSubview(titleLabel)
        addSubview(departmentLabel)
        addSubview(sizeLabel)
        addSubview(separatorView)
        addSubview(houseField)
        addSubview(roomField)
        addSubview(dateField)
        addSubview(buyNowButton)
        
        buyNowButton.left(16).right(16).top(to: .bottom(240), of: dateField)

        mainImageView.image = Asset.imagePlaceholder.image
        mainImageView.top(30).left(16).width(112).height(112)
        
        titleLabel.top(30).left(to: .right(16), of: mainImageView).width(200)
        titleLabel.text = "XL" + " · " + "Men's Nike J.J. Watt Black Arizona Cardinals Legend Jersey"
        titleLabel.textColor = textPrimaryColor
        titleLabel.font = UIFont(name: "Roboto-Regular", size: 14)
        titleLabel.lineBreakMode = .byWordWrapping
        titleLabel.numberOfLines = 2
        
        departmentLabel.top(to: .bottom(8), of: titleLabel).left(to: .right(16), of: mainImageView).width(210)
        departmentLabel.text = "Джерси"
        departmentLabel.textColor = textSecondaryColor
        departmentLabel.font = UIFont(name: "Roboto-Regular", size: 10)
        
        stepperView.top(to: .bottom(16), of: titleLabel).height(60).width(95).right(16)
        stepperView.layer.cornerRadius = 6
        stepperView.layer.borderWidth = 1
        stepperView.layer.borderColor = UIColor.gray.cgColor
        
        quantity.text = "\(Int(stepCounter.value))"
        quantity.height(20).width(95)
        quantity.backgroundColor = .white
        quantity.textAlignment = .center
        stepCounter.bottom()
        
        houseField.left(16).top(to: .bottom(48), of: mainImageView).right(16)
        roomField.left(16).top(to: .bottom(32), of: houseField).right(16)
        dateField.left(16).top(to: .bottom(32), of: roomField).right(16)
        
        houseField.title = "Дом"
        roomField.title = "Квартира"
        dateField.title = "Дата доставки"

    }
}
