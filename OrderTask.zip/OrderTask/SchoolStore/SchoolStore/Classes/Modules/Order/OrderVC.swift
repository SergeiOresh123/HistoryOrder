//
//  OrderVC.swift
//  SchoolStore
//
//  Created by Heads on 25.10.2021.
//

import AutoLayoutSugar
import Foundation
import UIKit

final class OrderVC: UIViewController {
    // MARK: Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(scrollView)
        view.addSubview(topView)
        topView.top().left().right().height(70)
        topView.backgroundColor = .white
        topView.addSubview(returnButton)
        returnButton.top(30).left(16).height(44)
        returnButton.addTarget(self, action: #selector(BackBtn), for: .touchUpInside)
        scrollView.addSubview(contentView)
        scrollView.pinToSuperview()
        contentView.pinToSuperview()
            .width(as: scrollView)
        scrollView
            .heightAnchor
            .constraint(lessThanOrEqualTo: contentView.heightAnchor)
            .activate()

    }
    
    @objc func BackBtn() {
        let alertController = UIAlertController(title: "Вернуться в каталог?", message: nil, preferredStyle: .alert)
         
        let LogOutAction = UIAlertAction(title: "Вернуться", style: .default) { (action) -> Void in
            UIApplication.shared.windows.first(where: { $0.isKeyWindow })?.rootViewController = VCFactory.buildTabBarVC()
            
            }
             
        let CloseAction = UIAlertAction(title: "Отмена", style: .default) { (action) -> Void in
              
            }
           
            alertController.addAction(LogOutAction)
            alertController.addAction(CloseAction)
           
        self.present(alertController, animated: true, completion: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.isNavigationBarHidden = false
    }

    // MARK: Internal

    var product: Product? {
        didSet {
            contentView.fillWith(product: product)
        }
    }

    // MARK: Private

    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()
    
    private lazy var returnButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.font = UIFont(name: "Roboto", size: 10.0)
        button.setTitle("Назад", for: .normal)
        button.setTitleColor(UIColor(red: 0.0, green: 0.207, blue: 0.58, alpha: 1.0), for: .normal)
        return button
    }()
    
    private lazy var topView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private lazy var contentView: OrderView = {
        let contentView = OrderView()
        contentView.translatesAutoresizingMaskIntoConstraints = false
        return contentView
    }()
}


