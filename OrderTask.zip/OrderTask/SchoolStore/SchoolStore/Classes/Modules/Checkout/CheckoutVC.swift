//
//  CheckoutVC.swift
//  SchoolStore
//
//  Created by a1 on 22.10.2021.
//

import Foundation
import UIKit
import AutoLayoutSugar
import Kingfisher

final class CheckoutVC: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        title = L10n.Checkout.title
    }
    
    private lazy var contentImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = Asset.itemPlaceholder.image
        return imageView
    }()
    
    private lazy var productTitle: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var departmentTitle: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
}
