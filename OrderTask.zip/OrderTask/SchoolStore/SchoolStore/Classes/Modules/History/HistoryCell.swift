//
//  HistoryCell.swift
//  SchoolStore
//
//  Created by a1 on 21.10.2021.
//

import AutoLayoutSugar
import Foundation
import Kingfisher
import UIKit

final class HistoryCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    var model: Order? {
        didSet{
            if let preview = model?.productPreview, let previewUrl = URL(string: preview) {
                let contentImageResource = ImageResource(downloadURL: previewUrl, cacheKey: preview)
                contentImageView.kf.setImage(
                    with: contentImageResource,
                    placeholder: Asset.itemPlaceholder.image,
                    options: [
                        .transition(.fade(0.2)),
                        .forceTransition,
                        .cacheOriginalImage,
                        .keepCurrentImageWhileLoading,
                    ]
                )
            } else {
                contentImageView.image = Asset.itemPlaceholder.image
            }
            
            guard let date = model?.createdAt,
                  let numberOrder = model?.number,
                  let statusOrder = model?.status,
                  let productQuantity = model?.productQuantity,
                  let productSize = model?.productSize,
                  let titleOrder = model?.title,
                  let etd = model?.etd,
                  let deliveryAddress = model?.deliveryAddress
            else {
                return
            }
            
            let formatter = ISO8601DateFormatter()
            let tmp = formatter.date(from: date)
            let tmp1 = formatter.date(from: etd)
            
            guard let stringDate = tmp?.stringDate,
                  let stringEtd = tmp1?.stringDate
            else {
                return
            }
            
            numberOfOrder.text = "Заказ №" + String(numberOrder) + " от " + stringDate
            
            switch statusOrder {
            case .inWork:
                statusOfOrder.text = "В работе"
                statusOfOrder.textColor = .systemGreen
            case .done:
                break
            case .cancelled:
                statusOfOrder.text = "Отменен"
                statusOfOrder.textColor = .red
            }
            
            nameOfProduct.text = "\(productQuantity) × " + "\(productSize) · " + titleOrder
            dateAdressOrder.text = "Дата доставки: \(stringEtd)" + "\nАдрес доставки: \(deliveryAddress)"
        }
    }
    
    private lazy var contentImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = Asset.itemPlaceholder.image
        return imageView
    }()
    
    private lazy var numberOfOrder: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.numberOfLines = 3
        return label
    }()
    
    private lazy var statusOfOrder: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 18, weight: .medium)
        return label
    }()
    
    private lazy var nameOfProduct: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.numberOfLines = 3
        return label
    }()
    
    private lazy var dateAdressOrder: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.numberOfLines = 3
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = .gray
        return label
    }()
    
    private lazy var separatorView: UIView = {
            let view = UIView()
            view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .gray
            return view
        }()

    private func setup() {
        selectionStyle = .none
        contentView.addSubview(contentImageView)
        contentView.addSubview(numberOfOrder)
        contentView.addSubview(statusOfOrder)
        contentView.addSubview(nameOfProduct)
        contentView.addSubview(dateAdressOrder)
        contentView.addSubview(separatorView)
        
        contentImageView.top(32).left(16).width(64).height(63.02).bottom(70)
        
        numberOfOrder.top(16).left(to: .right(8), of: contentImageView).right(16)
        numberOfOrder.textColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)

        statusOfOrder.top(to: .bottom(8), of: numberOfOrder).left(to: .right(8), of: contentImageView).right(16)
        statusOfOrder.textColor = UIColor(red: 0.298, green: 0.686, blue: 0.313, alpha: 0.87)

        nameOfProduct.top(to: .bottom(8), of: statusOfOrder).left(to: .right(8), of: contentImageView).right(16)
        nameOfProduct.textColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)

        dateAdressOrder.top(to: .bottom(8), of: nameOfProduct).left(to: .right(8), of: contentImageView).right(16)

        dateAdressOrder.textColor = UIColor(red: 0.643, green: 0.643, blue: 0.643, alpha: 1.0)

        separatorView.backgroundColor = Asset.fieldBacground.color
        separatorView.top(to: .bottom(8), of: dateAdressOrder).left(16).right(16).height(1)
    }
}

extension Date {

    var stringDate: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy 'в' hh:mm"
        return formatter.string(from: self)
    }

}
